package com.example.groupproject;
import android.app.Application;
public class GlobalVariable extends Application{
    private  String Name;
    public void setName(String name){
        this.Name = name;
    }

    public String getName(){
        return Name;
    }
}
