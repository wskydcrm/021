package com.example.groupproject;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.view.Window;


public class front_page extends AppCompatActivity {

    ImageButton mimagebutton,mimagebutton2,mimagebutton4,mimagebutton5,mimagebutton6;
    Button mbutton,mbutton1,mbutton3;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getSupportActionBar().hide();
        setContentView(R.layout.front_page);

        mimagebutton = findViewById(R.id.imageButton);
        mimagebutton2 = findViewById(R.id.imageButton2);
        mimagebutton4 = findViewById(R.id.imageButton3);
        mimagebutton5 = findViewById(R.id.imageButton6);
        mimagebutton6 = findViewById(R.id.imageButton8);
        mbutton3 = findViewById(R.id.button10);

        mbutton = findViewById(R.id.button3);
        mbutton1 = findViewById(R.id.button4);

        mimagebutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(front_page.this,DrinkActivity.class);
                startActivity(intent);
            }
        });
        mbutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(front_page.this,DrinkActivity.class);
                startActivity(intent);
            }
        });
        mimagebutton2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(front_page.this,search.class);
                startActivity(intent);
            }
        });
        mimagebutton4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(front_page.this,MainActivity7.class);
                startActivity(intent);
            }
        });
        mimagebutton5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(front_page.this,Notify.class);
                startActivity(intent);
            }
        });
        mimagebutton6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(front_page.this,Bookkeeping.class);
                startActivity(intent);
            }
        });
        mbutton1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
        mbutton3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(front_page.this,member.class);
                startActivity(intent);
            }
        });

    }
}